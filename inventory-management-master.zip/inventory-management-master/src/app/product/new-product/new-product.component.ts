import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'new-product',
  templateUrl: './new-product.component.html',
  styleUrls: ['./new-product.component.css']
})
export class NewProductComponent implements OnInit {
  title = "New product";

  constructor() { }

  ngOnInit() {
  }

}
