# Stock-Management-System
It's an inventory management system created using python having database implemented in SQLite3 and GUI implemented in PyQt5

# Steps to Run
1.EDIT the path of the folder that contains stockmanager.py in the given shell script.
2.Set the .sh file as executable and run it.

# Steps to Use
- Login using the Username and Password set in the code.
- Add Stock information using the first option in the list.
- Edit quantity of a product or delete a product using Manage Stock option.
- View the database elements using View stock.
- Check the Transaction History using the last option.

